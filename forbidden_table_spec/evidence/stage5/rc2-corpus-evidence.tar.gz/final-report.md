# Stage 4 Beta seeded simulation corpus

- Completion: `COMPLETE_1000_CASE_CORPUS`
- Run state: `COMPLETE`
- Gate evidence eligible: `true`
- Simulation gate: `PASS` (pass `true`)
- Manifest: `7de24caa762caef8650a23e31df4999612f3ea0aa633edbe2688c06e34567663` (artifact SHA-256 `5df2e52634015661e3b0e49a7eabbbceed1e170c9cb32a1212f94705dc5b472b`)
- Summary JSONL: `/tmp/forbidden-table-stage5-corpus-rc2-9279/final-summary.jsonl` (SHA-256 `de7fd39786f45c55e995d4596d1300ca927acc61e8b070f9c9a9e25a5f4b5630`)

## Build and schema

- Project version: `1.0.0-rc.2`; engine: `{"build":"official","hash":"ed1daf0bf001b61586d9930840f2f1394092c079","hex":263938,"major":4,"minor":7,"patch":2,"status":"stable","string":"4.7.2-stable (official)","timestamp":0}`
- Content version: `content.bundle.v1.alpha.act_two@v5+alpha.scale@v12+phase2@v4`; manifest schema: `1`; corpus schema: `alpha.gate-corpus-jsonl.v3`
- Game version: `game.phase2.v1`; SuspendSnapshot schema: `1`; MetaProgressSnapshot schema: `2`; ReplayRecord schema: `1`
- Base Git revision: `54a8d09635a6ab136ac3c1ce10bca4508799053b`
- Runtime source snapshot SHA-256: `55184c663c7f4a0cd8290e9a943f7a568c14a6d0de97afd0f6e571c276ac69c5` (262 files)
- Snapshot scope: SHA-256 of every non-UID file recursively under src/, scenes/, and scripts/, plus project.godot. This identifies the runtime code/content/config snapshot; tests, docs, .godot, and .cache are excluded.

## Execution bounds and commands

- Cases: `1000/1000`; attempts per case: `2`; cooperative attempt watchdog: `120000 ms`; per-chunk process timeout: `600 s`; kill-after: `30 s`.
- Finalization command: `/usr/bin/timeout --signal=TERM --kill-after=30s 600 '/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64' --headless --path '/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/' --script res://scripts/run_alpha_gate_corpus.gd -- --full --finalize --gate stage4_beta --output /tmp/forbidden-table-stage5-corpus-rc2-9279/final-summary.jsonl --manifest-output /tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json --report-output /tmp/forbidden-table-stage5-corpus-rc2-9279/final-report.md --process-timeout-seconds 600 --process-timeout-enforced --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-047.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-048.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-049.jsonl --resume-from /tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-050.jsonl`

## Policy outcomes

```json
{
	"Complete": {
		"DEFEAT": 94,
		"VICTORY": 239
	},
	"Hybrid": {
		"DEFEAT": 102,
		"VICTORY": 231
	},
	"Partial": {
		"DEFEAT": 334,
		"VICTORY": 0
	}
}
```

Terminal outcomes: `{"DEFEAT":530,"VICTORY":470}`.

## Strategy distributions

```json
{
	"Complete": {
		"accepted_action_counts": {
			"ChooseCharacter": 333,
			"ChooseContract": 333,
			"ChooseEventOption": 331,
			"ChooseReward": 3036,
			"DiscardTile": 1134,
			"Draw": 47137,
			"EndTurn": 17557,
			"EnterEvent": 331,
			"EnterWorkshop": 329,
			"ExitWorkshop": 329,
			"SelectMapNode": 3790,
			"SettleCompleteHand": 4180,
			"SettlePattern": 6613,
			"StoreTile": 9832,
			"UseWorkshopService": 26
		},
		"accepted_command_count": 95291,
		"attempt_count": 333,
		"complete_hand_settlements": 4180,
		"partial_settlements": 6613
	},
	"Hybrid": {
		"accepted_action_counts": {
			"ChooseCharacter": 333,
			"ChooseContract": 333,
			"ChooseEventOption": 335,
			"ChooseReward": 3018,
			"DiscardTile": 13159,
			"Draw": 46813,
			"EndTurn": 17652,
			"EnterEvent": 335,
			"EnterWorkshop": 329,
			"ExitWorkshop": 329,
			"SelectMapNode": 3784,
			"SettleCompleteHand": 4144,
			"SettlePattern": 6598,
			"UseWorkshopService": 27
		},
		"accepted_command_count": 97189,
		"attempt_count": 333,
		"complete_hand_settlements": 4144,
		"partial_settlements": 6598
	},
	"Partial": {
		"accepted_action_counts": {
			"ChooseCharacter": 334,
			"ChooseContract": 334,
			"DiscardTile": 2046,
			"Draw": 4984,
			"EndTurn": 2482,
			"SelectMapNode": 334,
			"SettlePattern": 668
		},
		"accepted_command_count": 11182,
		"attempt_count": 334,
		"complete_hand_settlements": 0,
		"partial_settlements": 668
	},
	"UNKNOWN": {
		"accepted_action_counts": {},
		"accepted_command_count": 0,
		"attempt_count": 0,
		"complete_hand_settlements": 0,
		"partial_settlements": 0
	}
}
```

## Source chunks

Verified GNU timeout statuses: `50`; process timeouts: `0`; nonzero chunk exits: `0`.

- Cases 1–20 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl`, SHA-256 `9d03e489d7830e3172d278956c2bf136b124ebed92c711bdb5589090eaf1eed8`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl.status.json` (SHA-256 `3362eeead7bc717b8e9688688a1d1980263fd7834f17af9896f8d77771c0e4be`); output SHA-256 `9d03e489d7830e3172d278956c2bf136b124ebed92c711bdb5589090eaf1eed8`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 21–40 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl`, SHA-256 `7587f1cec1d1bb404c2287460a30da349e9a3b439b57d6d7245b89be166318e7`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl.status.json` (SHA-256 `edf26eda65785a10b9a96db3497e71d172295ab34eb3a99abbedd98b80b874a8`); output SHA-256 `7587f1cec1d1bb404c2287460a30da349e9a3b439b57d6d7245b89be166318e7`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 41–60 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl`, SHA-256 `bc1494e5b1717818fae3f39cc3557cdd3a4794250f6bc5de1427663919c24a1d`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl.status.json` (SHA-256 `066e140e3a4b10a93209be748d9cc521690b9537dd159151732f6d779afe9a2f`); output SHA-256 `bc1494e5b1717818fae3f39cc3557cdd3a4794250f6bc5de1427663919c24a1d`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 61–80 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl`, SHA-256 `cc0d8a3bea6976e7ea25fb0bc796231f75d0fe4c1a665f937c06d713649c5ef7`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl.status.json` (SHA-256 `4ec850c35294a53dc38dbef220f81ea8446ae25035aba879e03367e6e9be4995`); output SHA-256 `cc0d8a3bea6976e7ea25fb0bc796231f75d0fe4c1a665f937c06d713649c5ef7`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 81–100 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl`, SHA-256 `0a295e58544f047132f12b294c45b595ea3383a1f214ed016ff4c6f829dbf35a`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl.status.json` (SHA-256 `a81f578012479b39d44a9102a03b129051b4895bf2682ca14bd85c26e2ab17c6`); output SHA-256 `0a295e58544f047132f12b294c45b595ea3383a1f214ed016ff4c6f829dbf35a`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 101–120 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl`, SHA-256 `477d03496368af7d4223c1dc8969a37915cfd477d1bb233188c01654242c2c19`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl.status.json` (SHA-256 `5e51fd337e652c2661eb8fcc1b54950fa295c79548aac30ca7b6eb8bf3983a03`); output SHA-256 `477d03496368af7d4223c1dc8969a37915cfd477d1bb233188c01654242c2c19`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 121–140 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl`, SHA-256 `07cd14880d0444fa0523045f5f5deaf05f91efe2402055ae87d71bba25036454`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl.status.json` (SHA-256 `291d8c72de3b0476e9f2f036858ac74bf72603857ed8f8201e81c04cd224c445`); output SHA-256 `07cd14880d0444fa0523045f5f5deaf05f91efe2402055ae87d71bba25036454`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 141–160 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl`, SHA-256 `976ad1290661508e2a084423d05877716366816be21fac438926cf78a33b2ef0`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl.status.json` (SHA-256 `ed598a3a89d44ed1baa3d3ff4b12c0d36745fe716062746dae889173499e6302`); output SHA-256 `976ad1290661508e2a084423d05877716366816be21fac438926cf78a33b2ef0`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 161–180 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl`, SHA-256 `3ba592b810aa723bc6bd3b16d6b1665b06987df5eebe0253ea98822c552f9bbd`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl.status.json` (SHA-256 `918f16bab25e279a41d266e479f3d17368e08a51ef30131aae3b331b9e0fe89d`); output SHA-256 `3ba592b810aa723bc6bd3b16d6b1665b06987df5eebe0253ea98822c552f9bbd`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 181–200 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl`, SHA-256 `546af203c52dbde6fb6042690849c61ba2aea554e02b235190cf2cde557fe976`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl.status.json` (SHA-256 `a7261639cd8d930df80e355609bd88646ad47f513d71e471eaebab690b735e5c`); output SHA-256 `546af203c52dbde6fb6042690849c61ba2aea554e02b235190cf2cde557fe976`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 201–220 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl`, SHA-256 `41645addce1a1eae40bb8e82daff0b6e0d40ee45ee38e6ed9b3d82935242b556`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl.status.json` (SHA-256 `00d1f3ca707bc9c955126f5a5b33eefd968d00a903176487471a1817d02d90b7`); output SHA-256 `41645addce1a1eae40bb8e82daff0b6e0d40ee45ee38e6ed9b3d82935242b556`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 221–240 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl`, SHA-256 `34e5aea5c05830fb8288aff80c4cdb72d4ac9a96aef4a44346c29af9a01633c6`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl.status.json` (SHA-256 `c399df9cb74eae09d89af25e1ca809c4ddad0a9d8e2674d9d46a61e1fd1f650a`); output SHA-256 `34e5aea5c05830fb8288aff80c4cdb72d4ac9a96aef4a44346c29af9a01633c6`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 241–260 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl`, SHA-256 `a365dbbebcb7aa38fca131bce933c50b8f3f153b8f87a814f95df2ea7e4717a3`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl.status.json` (SHA-256 `512c485f22fe79b62a233d6f321c8297e1acf67993add977ed5750b337457b2c`); output SHA-256 `a365dbbebcb7aa38fca131bce933c50b8f3f153b8f87a814f95df2ea7e4717a3`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 261–280 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl`, SHA-256 `d8180d4959be3a2e54fa4e1ad539b27e9288141ee1826ef7aad7d4085bf46d27`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl.status.json` (SHA-256 `87e066f6d41c3488c4e5b48cb96d783e205325cf4912318ff237ebd212898e38`); output SHA-256 `d8180d4959be3a2e54fa4e1ad539b27e9288141ee1826ef7aad7d4085bf46d27`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 281–300 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl`, SHA-256 `bf7ea64b788c31ecaf64d3e4e782126779e2e92b5d242d831f110e4697f4e4af`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl.status.json` (SHA-256 `f06ee35c295fc4ca9423ce5c1d167a847ecd1a32448fa8a481826850f792b660`); output SHA-256 `bf7ea64b788c31ecaf64d3e4e782126779e2e92b5d242d831f110e4697f4e4af`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 301–320 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl`, SHA-256 `e141420b6c84588cff1e0b8f36a9d44957ef2cb5115c7ae94ef0968f116622be`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl.status.json` (SHA-256 `a0c901763bbe2b72b68411632e50f6d29b3beb94a8b4854a474e10bcaac40688`); output SHA-256 `e141420b6c84588cff1e0b8f36a9d44957ef2cb5115c7ae94ef0968f116622be`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 321–340 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl`, SHA-256 `4f35c65581c53adeeb606d03baaa02e333b479718d943cfad5562a1ced9b027e`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl.status.json` (SHA-256 `9c9b3f681e230e29988b7b4da45f02fa6ea753e9ea00449283c1c04670e5cc31`); output SHA-256 `4f35c65581c53adeeb606d03baaa02e333b479718d943cfad5562a1ced9b027e`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 341–360 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl`, SHA-256 `3312007b75005224a88d509caed9bb705bd1ca83799a9af9553f766faf14da55`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl.status.json` (SHA-256 `eb3019ae24a3f41a1aa1e10524727da26698eeec27fb37c18f8d49772b67e468`); output SHA-256 `3312007b75005224a88d509caed9bb705bd1ca83799a9af9553f766faf14da55`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 361–380 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl`, SHA-256 `fe4f68ee9a27e56f20a30d289c5f937e436098566b974f575b9bdec496770fd0`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl.status.json` (SHA-256 `cc7bbd4f9b142a4f1b9f217c670470ef86e7d8f4f09eb7bc1bf0d9375be40d43`); output SHA-256 `fe4f68ee9a27e56f20a30d289c5f937e436098566b974f575b9bdec496770fd0`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 381–400 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl`, SHA-256 `df1f67c897eb431e1cd23c8d4e230807df6fac18d8c036f9c649110017b2c581`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl.status.json` (SHA-256 `de9bb6d32df57d6a4578d073e999623a75e84332b42b2593af90f7d3d2fcdbb8`); output SHA-256 `df1f67c897eb431e1cd23c8d4e230807df6fac18d8c036f9c649110017b2c581`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 401–420 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl`, SHA-256 `384ae78fffc94a036452caf02939ee5567a8cfa5551abe781d0b7d5cf9c8e9bb`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl.status.json` (SHA-256 `66271b66a8135ae4a4dcd286b4775d6c63b2369d82b43e39d65fb0c66818f943`); output SHA-256 `384ae78fffc94a036452caf02939ee5567a8cfa5551abe781d0b7d5cf9c8e9bb`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 421–440 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl`, SHA-256 `50a90d92b9cfc5d29a4710ee27cb06b286a5a9a593a535963d0064bd70c598ff`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl.status.json` (SHA-256 `79d639c80879636707c258d3c5f34e981d8be53ba5ebaddaed24d98373fde616`); output SHA-256 `50a90d92b9cfc5d29a4710ee27cb06b286a5a9a593a535963d0064bd70c598ff`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 441–460 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl`, SHA-256 `efc79afaf17068c5260878152b7537c0bee09b9fdd25d834ce7bcc14c8814c3d`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl.status.json` (SHA-256 `3e8b9187b26bab02b29a24f29c04cf9ea4bf6398a10c9aa3956a5f1e95c93af6`); output SHA-256 `efc79afaf17068c5260878152b7537c0bee09b9fdd25d834ce7bcc14c8814c3d`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 461–480 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl`, SHA-256 `c073f4288b8dbd5729533347ed21859654e3619164d55a92b97f5ccee873347a`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl.status.json` (SHA-256 `807f9045934db8f51b9d8e041edaa23c170767f8314461b526d80592dd2d87c2`); output SHA-256 `c073f4288b8dbd5729533347ed21859654e3619164d55a92b97f5ccee873347a`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 481–500 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl`, SHA-256 `1765a4822bcc4795d493283b162c63257f86c432b910f6b2e60b02cc287f57f0`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl.status.json` (SHA-256 `d8008cdb8aa10ce5bcb533e9ec77655fb718fa14cfbd7685bd32906f744932cb`); output SHA-256 `1765a4822bcc4795d493283b162c63257f86c432b910f6b2e60b02cc287f57f0`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 501–520 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl`, SHA-256 `6cdbd33e6b62de16adf60eb6c08c9887619c96b7b958e3e698a73cb476c9cbcb`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl.status.json` (SHA-256 `c932c047cb53aaeadf013c6b2b6e419adf19c74fb412cc2c2a435c6750638a20`); output SHA-256 `6cdbd33e6b62de16adf60eb6c08c9887619c96b7b958e3e698a73cb476c9cbcb`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 521–540 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl`, SHA-256 `7aa4cce27670a8ff43d3fd6303153bcb5b91586bb35de36797296f315172889f`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl.status.json` (SHA-256 `19b6e79eefd22e34828d77d98712aa96aed6756690632aa865d09d97f949835e`); output SHA-256 `7aa4cce27670a8ff43d3fd6303153bcb5b91586bb35de36797296f315172889f`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 541–560 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl`, SHA-256 `b31971d5e9b20145ad59ca00579c1f1503306ad0af5cdcc79204165d7ede69ec`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl.status.json` (SHA-256 `7571f5c83590b5e90a77c292db7bbba9c52c1cdbaff0d1f9d0e60c5e163cc831`); output SHA-256 `b31971d5e9b20145ad59ca00579c1f1503306ad0af5cdcc79204165d7ede69ec`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 561–580 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl`, SHA-256 `c2f722e944ff42223807bc98edca94c7543ea5677a9cd23085fe1997b751a5d2`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl.status.json` (SHA-256 `309f83ee54c66ec5df6525718a30baefe527ff99948a117c0686fcc6eba1f34e`); output SHA-256 `c2f722e944ff42223807bc98edca94c7543ea5677a9cd23085fe1997b751a5d2`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 581–600 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl`, SHA-256 `a306814356d25b47ba15027994458e0f76b002e57945ecc87b529c9a833e78e6`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl.status.json` (SHA-256 `185c1e0fc177a6ed28784eade0e88bbbef7585be835bdf1baf4a447bb957c4b4`); output SHA-256 `a306814356d25b47ba15027994458e0f76b002e57945ecc87b529c9a833e78e6`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 601–620 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl`, SHA-256 `6a37212542efd2bc8a2b835e2627271e06c4231c7cf15b73fbaea7d41921da09`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl.status.json` (SHA-256 `07f9497ef7935bf9b7dc59e03018f2bd023097f183d8696c544a8a279558ea3a`); output SHA-256 `6a37212542efd2bc8a2b835e2627271e06c4231c7cf15b73fbaea7d41921da09`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 621–640 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl`, SHA-256 `4b1add4360ed5c33527cd8d985ade2d33e472e48a18de10cd3884fc22b974e4e`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl.status.json` (SHA-256 `e2717a75b1c16931bd5a32e5235327fdbb842cb03fe911809e76c70c5ed2f081`); output SHA-256 `4b1add4360ed5c33527cd8d985ade2d33e472e48a18de10cd3884fc22b974e4e`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 641–660 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl`, SHA-256 `58ef3fb6b144c13128d915e479acbe5b1defd093506ee93eb5f5cace8f896bc8`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl.status.json` (SHA-256 `383639ff8200d3ee8cd27ced292dfb740d86ab857f9200f5ba3f6718efe5d1c5`); output SHA-256 `58ef3fb6b144c13128d915e479acbe5b1defd093506ee93eb5f5cace8f896bc8`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 661–680 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl`, SHA-256 `17acae2de956718bc70cfd3fa6b6d4fac72576daa6ec061dabc71687af8016b9`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl.status.json` (SHA-256 `4569ca12c76b67d20c444ef62c1fea16889e131549b5ec52a9c4bc45d4544581`); output SHA-256 `17acae2de956718bc70cfd3fa6b6d4fac72576daa6ec061dabc71687af8016b9`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 681–700 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl`, SHA-256 `e3888509c163c4c91a4fe27dd352848593ef5434df3b577d60153abd38b53e9e`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl.status.json` (SHA-256 `d5a7eee6bfba60961258af7a36a2b2f6484481c0e7e489607566850a3734c21a`); output SHA-256 `e3888509c163c4c91a4fe27dd352848593ef5434df3b577d60153abd38b53e9e`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 701–720 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl`, SHA-256 `09645d26e4f1b790bf6cf2c61c4696bf9a94099f4faa9234ea205dfad362446d`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl.status.json` (SHA-256 `596bf164e9b03dca105b82a0543f5e6a6ef551760e5dcd2f40f26da7cdad1af1`); output SHA-256 `09645d26e4f1b790bf6cf2c61c4696bf9a94099f4faa9234ea205dfad362446d`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 721–740 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl`, SHA-256 `5ef17e66154dba74217f02eb1594af40b30d1dd7605bfb9b8461ab8873c8e4b2`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl.status.json` (SHA-256 `fd44f3c38cb1afa126f9a75767b586336056e1cc88627f38119739fdf2be54e3`); output SHA-256 `5ef17e66154dba74217f02eb1594af40b30d1dd7605bfb9b8461ab8873c8e4b2`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 741–760 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl`, SHA-256 `64e64f0149dbf8af5cdcc35c4953dc3c85738312b9ec34108eedfa738ccb07f8`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl.status.json` (SHA-256 `8e7742774fb713a8b28589bac4a2f20d6294c6511247042a32166235d7a703dd`); output SHA-256 `64e64f0149dbf8af5cdcc35c4953dc3c85738312b9ec34108eedfa738ccb07f8`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 761–780 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl`, SHA-256 `adbce542592f3ef23015a56206825216fd1774eb4ea71f6f8975496d43ab3873`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl.status.json` (SHA-256 `d013f58d019234ccf08af4228357da57a49bae7be151148aba82382953441d7b`); output SHA-256 `adbce542592f3ef23015a56206825216fd1774eb4ea71f6f8975496d43ab3873`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 781–800 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl`, SHA-256 `b2de1ad568bd4e36a59d4e7a33ef5cb1d20cc66b947b551dbc350b80c85baa29`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl.status.json` (SHA-256 `0fbbed980fdeac5a3252a381f402af41e27a07666dc443733922e47bb32f9356`); output SHA-256 `b2de1ad568bd4e36a59d4e7a33ef5cb1d20cc66b947b551dbc350b80c85baa29`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 801–820 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl`, SHA-256 `3069170ef054f6bdfb95a62e90036e3e418b901b6d180195fc43beb75f9e62c4`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl.status.json` (SHA-256 `f1f32bf34a468915292041dcaedbcf5e1e31187104cc95847ec0ab488ee614bb`); output SHA-256 `3069170ef054f6bdfb95a62e90036e3e418b901b6d180195fc43beb75f9e62c4`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 821–840 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl`, SHA-256 `7af6fb259344e9dbb26905dc0ebaf09ab2d7eef42e6fe6c93f107852e403631a`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl.status.json` (SHA-256 `4f32e0e9aba5effb9ee06bf3b0639c74567fc836ccde2f80cfa25ab3e0d24909`); output SHA-256 `7af6fb259344e9dbb26905dc0ebaf09ab2d7eef42e6fe6c93f107852e403631a`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 841–860 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl`, SHA-256 `764450fee2c165ad9425bc3397d4abaf0766d13cbf646547aeb10292d57b67c2`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl.status.json` (SHA-256 `85c6a22e84fca7a1a368086e86cfc899429178c73f47fb4c462cef5ca828279d`); output SHA-256 `764450fee2c165ad9425bc3397d4abaf0766d13cbf646547aeb10292d57b67c2`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 861–880 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl`, SHA-256 `7fad5b96dd1ad9daa4166abd088e89f91f52a9ecca01e240a28b211c708fb30b`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl.status.json` (SHA-256 `ac3e7b19778fd21c88a59bcdb5103fb8192c4219a696c15aabe27a9da81bd24e`); output SHA-256 `7fad5b96dd1ad9daa4166abd088e89f91f52a9ecca01e240a28b211c708fb30b`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 881–900 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl`, SHA-256 `dfdabff8956d923b14a32b0bd49a553c5aadc4e70caab5e6c2d6763567524b1f`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl.status.json` (SHA-256 `43eab817cc7d3a40bc40cf6430d4fb8255aea96d3662cd562353ae8be0df5bde`); output SHA-256 `dfdabff8956d923b14a32b0bd49a553c5aadc4e70caab5e6c2d6763567524b1f`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 901–920 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl`, SHA-256 `f2cfde4dcd9c906eac57f101edc12abdb792027d98e10c96a25887424484f0f4`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl.status.json` (SHA-256 `b681039eaac06359a022b1296bc6969494ecd53b0ae3a17f448ae411914bc888`); output SHA-256 `f2cfde4dcd9c906eac57f101edc12abdb792027d98e10c96a25887424484f0f4`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 921–940 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-047.jsonl`, SHA-256 `2eb0f5ed20e8ba9759f504f28c02bb149506ced400ef03b09aec2a10370fa9bb`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-047.jsonl.status.json` (SHA-256 `498fcf48ab4d528738505079b6f1694d6cb34ed8b58f69b9b7280ee9c9ca9d29`); output SHA-256 `2eb0f5ed20e8ba9759f504f28c02bb149506ced400ef03b09aec2a10370fa9bb`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-047.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 941–960 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-048.jsonl`, SHA-256 `9443880179026de828665248cb4035317e3580362263331c7bf8a6e38d110fb9`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-048.jsonl.status.json` (SHA-256 `ec8c831b606d840eaa9bb1a61de483e588755d466027bde8869cfc96575f703d`); output SHA-256 `9443880179026de828665248cb4035317e3580362263331c7bf8a6e38d110fb9`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-047.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-048.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 961–980 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-049.jsonl`, SHA-256 `4fe1fc6597f69939c40336ab944ef057ba40878556f26a912cd7125737e12aaf`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-049.jsonl.status.json` (SHA-256 `5ac76143c90d55117e4d86c7ba6c1d7a3a7b106c4f1d5bab789c2978a009603f`); output SHA-256 `4fe1fc6597f69939c40336ab944ef057ba40878556f26a912cd7125737e12aaf`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-047.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-048.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-049.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`
- Cases 981–1000 (20): `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-050.jsonl`, SHA-256 `9333c5fff0040669304011c230e45289636f28f4b87afc50a120c4dccd70c2e2`; GNU timeout exit `0` at `4830 s`; status `/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-050.jsonl.status.json` (SHA-256 `b136bff80bf047d07b9ff2c24f7ffa7838c36f34a95d0ffce4a8f06731f33d7c`); output SHA-256 `9333c5fff0040669304011c230e45289636f28f4b87afc50a120c4dccd70c2e2`.
  Command argv: `["/usr/bin/timeout","--signal=TERM","--kill-after=30s","4830","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table/.cache/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64","--headless","--path","/home/ubuntu/.codex/worktrees/stage5-release-plan/forbidden table","--script","res://scripts/run_alpha_gate_corpus.gd","--","--full","--gate","stage4_beta","--max-cases","20","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-001.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-002.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-003.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-004.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-005.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-006.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-007.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-008.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-009.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-010.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-011.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-012.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-013.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-014.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-015.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-016.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-017.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-018.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-019.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-020.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-021.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-022.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-023.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-024.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-025.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-026.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-027.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-028.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-029.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-030.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-031.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-032.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-033.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-034.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-035.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-036.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-037.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-038.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-039.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-040.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-041.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-042.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-043.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-044.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-045.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-046.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-047.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-048.jsonl","--resume-from","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-049.jsonl","--output","/tmp/forbidden-table-stage5-corpus-rc2-9279/chunk-050.jsonl","--manifest-output","/tmp/forbidden-table-stage5-corpus-rc2-9279/manifest.json","--process-timeout-seconds","4830","--process-timeout-enforced"]`
  Resolved GNU timeout executable: `/usr/bin/timeout`

## Observed usage coverage

The categories below report observed selection, acquisition, ownership, activation, scoring, and encounter facts against the #87 catalog budgets. They do not claim that every production item was used or that use was balanced.

```json
{
	"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
	"categories": {
		"acts": {
			"catalog_id_count": 2,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"reached_ids": [
					"ACT_1",
					"ACT_2"
				]
			},
			"observed_id_count": 2,
			"observed_ids": [
				"ACT_1",
				"ACT_2"
			],
			"observed_in_catalog_count": 2,
			"subcategories": {},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"bosses": {
			"catalog_id_count": 4,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"act_1_encountered_ids": [
					"alpha.boss.act_one.harbor_arbiter",
					"base.boss.table_breaker"
				],
				"act_2_encountered_ids": [
					"alpha.boss.act_two.final_index",
					"alpha.boss.act_two.tidal_archive"
				],
				"encountered_ids": [
					"alpha.boss.act_one.harbor_arbiter",
					"alpha.boss.act_two.final_index",
					"alpha.boss.act_two.tidal_archive",
					"base.boss.table_breaker"
				]
			},
			"observed_id_count": 4,
			"observed_ids": [
				"alpha.boss.act_one.harbor_arbiter",
				"alpha.boss.act_two.final_index",
				"alpha.boss.act_two.tidal_archive",
				"base.boss.table_breaker"
			],
			"observed_in_catalog_count": 4,
			"subcategories": {
				"act_1": {
					"catalog_id_count": 2,
					"catalog_source": "#87 Act 1 Boss budget: 2 IDs.",
					"evidence_kind": "act_1_encountered",
					"observed_ids": [
						"alpha.boss.act_one.harbor_arbiter",
						"base.boss.table_breaker"
					],
					"unused_ids": []
				},
				"act_2": {
					"catalog_id_count": 2,
					"catalog_source": "#87 Act 2 Boss budget: 2 IDs.",
					"evidence_kind": "act_2_encountered",
					"observed_ids": [
						"alpha.boss.act_two.final_index",
						"alpha.boss.act_two.tidal_archive"
					],
					"unused_ids": []
				}
			},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"characters": {
			"catalog_id_count": 3,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"selected_ids": [
					"alpha.character.harbor_reader",
					"base.character.reserve",
					"base.character.sequence"
				]
			},
			"observed_id_count": 3,
			"observed_ids": [
				"alpha.character.harbor_reader",
				"base.character.reserve",
				"base.character.sequence"
			],
			"observed_in_catalog_count": 3,
			"subcategories": {},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"contracts": {
			"catalog_id_count": 8,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"selected_ids": [
					"alpha.contract.brittle_compass",
					"alpha.contract.house_tithe",
					"alpha.contract.long_current",
					"alpha.contract.open_ledger",
					"alpha.contract.quiet_current",
					"base.contract.pool_bias",
					"base.contract.pressure",
					"base.contract.refinement_debt"
				]
			},
			"observed_id_count": 8,
			"observed_ids": [
				"alpha.contract.brittle_compass",
				"alpha.contract.house_tithe",
				"alpha.contract.long_current",
				"alpha.contract.open_ledger",
				"alpha.contract.quiet_current",
				"base.contract.pool_bias",
				"base.contract.pressure",
				"base.contract.refinement_debt"
			],
			"observed_in_catalog_count": 8,
			"subcategories": {},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"elite_enemies": {
			"catalog_id_count": 6,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"act_1_encountered_ids": [
					"alpha.enemy.act_one.elite.clockwork_auditor",
					"alpha.enemy.act_one.elite.drift_captain",
					"base.enemy.ledger_hunter"
				],
				"act_2_encountered_ids": [
					"alpha.enemy.act_two.elite.infernal_index",
					"alpha.enemy.act_two.elite.ledger_mimic",
					"alpha.enemy.act_two.elite.margin_enforcer"
				],
				"encountered_ids": [
					"alpha.enemy.act_one.elite.clockwork_auditor",
					"alpha.enemy.act_one.elite.drift_captain",
					"alpha.enemy.act_two.elite.infernal_index",
					"alpha.enemy.act_two.elite.ledger_mimic",
					"alpha.enemy.act_two.elite.margin_enforcer",
					"base.enemy.ledger_hunter"
				]
			},
			"observed_id_count": 6,
			"observed_ids": [
				"alpha.enemy.act_one.elite.clockwork_auditor",
				"alpha.enemy.act_one.elite.drift_captain",
				"alpha.enemy.act_two.elite.infernal_index",
				"alpha.enemy.act_two.elite.ledger_mimic",
				"alpha.enemy.act_two.elite.margin_enforcer",
				"base.enemy.ledger_hunter"
			],
			"observed_in_catalog_count": 6,
			"subcategories": {
				"act_1": {
					"catalog_id_count": 3,
					"catalog_source": "#87 Act 1 Elite budget: 3 IDs.",
					"evidence_kind": "act_1_encountered",
					"observed_ids": [
						"alpha.enemy.act_one.elite.clockwork_auditor",
						"alpha.enemy.act_one.elite.drift_captain",
						"base.enemy.ledger_hunter"
					],
					"unused_ids": []
				},
				"act_2": {
					"catalog_id_count": 3,
					"catalog_source": "#87 Act 2 Elite budget: 3 IDs.",
					"evidence_kind": "act_2_encountered",
					"observed_ids": [
						"alpha.enemy.act_two.elite.infernal_index",
						"alpha.enemy.act_two.elite.ledger_mimic",
						"alpha.enemy.act_two.elite.margin_enforcer"
					],
					"unused_ids": []
				}
			},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"events": {
			"catalog_id_count": 24,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"activated_ids": [
					"alpha.event.act_one.gold_exchange",
					"alpha.event.act_one.risk_bargain",
					"alpha.event.act_one.tile_surgery",
					"alpha.event.act_two.gold_exchange",
					"alpha.event.act_two.gold_exchange.long_margin",
					"alpha.event.act_two.risk_bargain",
					"alpha.event.act_two.risk_bargain.shadow_account",
					"alpha.event.act_two.tile_surgery",
					"alpha.event.act_two.tile_surgery.sealed_entry",
					"base.event.gold_exchange",
					"base.event.risk_bargain",
					"base.event.tile_surgery"
				]
			},
			"observed_id_count": 12,
			"observed_ids": [
				"alpha.event.act_one.gold_exchange",
				"alpha.event.act_one.risk_bargain",
				"alpha.event.act_one.tile_surgery",
				"alpha.event.act_two.gold_exchange",
				"alpha.event.act_two.gold_exchange.long_margin",
				"alpha.event.act_two.risk_bargain",
				"alpha.event.act_two.risk_bargain.shadow_account",
				"alpha.event.act_two.tile_surgery",
				"alpha.event.act_two.tile_surgery.sealed_entry",
				"base.event.gold_exchange",
				"base.event.risk_bargain",
				"base.event.tile_surgery"
			],
			"observed_in_catalog_count": 12,
			"subcategories": {
				"act_1": {
					"catalog_id_count": 12,
					"catalog_source": "Phase 2 plus Alpha Scale Act 1 event catalogs.",
					"evidence_kind": "",
					"observed_ids": [
						"alpha.event.act_one.gold_exchange",
						"alpha.event.act_one.risk_bargain",
						"alpha.event.act_one.tile_surgery",
						"base.event.gold_exchange",
						"base.event.risk_bargain",
						"base.event.tile_surgery"
					],
					"unused_ids": [
						"alpha.event.act_one.contract_clause",
						"alpha.event.act_one.map_reveal",
						"alpha.event.act_one.rule_memory",
						"base.event.contract_clause",
						"base.event.map_reveal",
						"base.event.rule_memory"
					]
				},
				"act_2": {
					"catalog_id_count": 12,
					"catalog_source": "Alpha Act Two event catalogs.",
					"evidence_kind": "",
					"observed_ids": [
						"alpha.event.act_two.gold_exchange",
						"alpha.event.act_two.gold_exchange.long_margin",
						"alpha.event.act_two.risk_bargain",
						"alpha.event.act_two.risk_bargain.shadow_account",
						"alpha.event.act_two.tile_surgery",
						"alpha.event.act_two.tile_surgery.sealed_entry"
					],
					"unused_ids": [
						"alpha.event.act_two.contract_clause",
						"alpha.event.act_two.contract_clause.amended_clause",
						"alpha.event.act_two.map_reveal",
						"alpha.event.act_two.map_reveal.final_annotation",
						"alpha.event.act_two.rule_memory",
						"alpha.event.act_two.rule_memory.cross_reference"
					]
				}
			},
			"unexpected_observed_ids": [],
			"unused_ids": [
				"alpha.event.act_one.contract_clause",
				"alpha.event.act_one.map_reveal",
				"alpha.event.act_one.rule_memory",
				"alpha.event.act_two.contract_clause",
				"alpha.event.act_two.contract_clause.amended_clause",
				"alpha.event.act_two.map_reveal",
				"alpha.event.act_two.map_reveal.final_annotation",
				"alpha.event.act_two.rule_memory",
				"alpha.event.act_two.rule_memory.cross_reference",
				"base.event.contract_clause",
				"base.event.map_reveal",
				"base.event.rule_memory"
			]
		},
		"modifiers": {
			"catalog_id_count": 12,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"activated_ids": [
					"base.modifier.clean_surface",
					"content.base.relic.rule_memory",
					"content.base.relic.workshop_kit",
					"event.risk_bargain.accept"
				]
			},
			"observed_id_count": 4,
			"observed_ids": [
				"base.modifier.clean_surface",
				"content.base.relic.rule_memory",
				"content.base.relic.workshop_kit",
				"event.risk_bargain.accept"
			],
			"observed_in_catalog_count": 1,
			"subcategories": {},
			"unexpected_observed_ids": [
				"content.base.relic.rule_memory",
				"content.base.relic.workshop_kit",
				"event.risk_bargain.accept"
			],
			"unused_ids": [
				"alpha.modifier.double_edge",
				"alpha.modifier.harbor_mark",
				"alpha.modifier.quiet_surface",
				"alpha.modifier.refinement_trace",
				"alpha.modifier.sharp_current",
				"alpha.modifier.trade_mark",
				"alpha.modifier.wide_channel",
				"base.modifier.flexible_identity",
				"base.modifier.recycling",
				"base.modifier.reserve_bound",
				"base.modifier.settlement_focus"
			]
		},
		"normal_enemies": {
			"catalog_id_count": 14,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"act_1_encountered_ids": [
					"alpha.enemy.act_one.fog_caller",
					"alpha.enemy.act_one.margin_taker",
					"alpha.enemy.act_one.signal_keeper",
					"base.enemy.contaminator",
					"base.enemy.integrity_collector",
					"base.enemy.pressure_sentinel",
					"base.enemy.wall_taxer"
				],
				"act_2_encountered_ids": [
					"alpha.enemy.act_two.afterimage",
					"alpha.enemy.act_two.contract_harrier",
					"alpha.enemy.act_two.echo_courier",
					"alpha.enemy.act_two.lien_keeper",
					"alpha.enemy.act_two.pressure_warden",
					"alpha.enemy.act_two.tollkeeper",
					"alpha.enemy.act_two.wall_eater"
				],
				"encountered_ids": [
					"alpha.enemy.act_one.fog_caller",
					"alpha.enemy.act_one.margin_taker",
					"alpha.enemy.act_one.signal_keeper",
					"alpha.enemy.act_two.afterimage",
					"alpha.enemy.act_two.contract_harrier",
					"alpha.enemy.act_two.echo_courier",
					"alpha.enemy.act_two.lien_keeper",
					"alpha.enemy.act_two.pressure_warden",
					"alpha.enemy.act_two.tollkeeper",
					"alpha.enemy.act_two.wall_eater",
					"base.enemy.contaminator",
					"base.enemy.integrity_collector",
					"base.enemy.pressure_sentinel",
					"base.enemy.wall_taxer"
				]
			},
			"observed_id_count": 14,
			"observed_ids": [
				"alpha.enemy.act_one.fog_caller",
				"alpha.enemy.act_one.margin_taker",
				"alpha.enemy.act_one.signal_keeper",
				"alpha.enemy.act_two.afterimage",
				"alpha.enemy.act_two.contract_harrier",
				"alpha.enemy.act_two.echo_courier",
				"alpha.enemy.act_two.lien_keeper",
				"alpha.enemy.act_two.pressure_warden",
				"alpha.enemy.act_two.tollkeeper",
				"alpha.enemy.act_two.wall_eater",
				"base.enemy.contaminator",
				"base.enemy.integrity_collector",
				"base.enemy.pressure_sentinel",
				"base.enemy.wall_taxer"
			],
			"observed_in_catalog_count": 14,
			"subcategories": {
				"act_1": {
					"catalog_id_count": 7,
					"catalog_source": "#87 Act 1 Normal enemy budget: 7 IDs.",
					"evidence_kind": "act_1_encountered",
					"observed_ids": [
						"alpha.enemy.act_one.fog_caller",
						"alpha.enemy.act_one.margin_taker",
						"alpha.enemy.act_one.signal_keeper",
						"base.enemy.contaminator",
						"base.enemy.integrity_collector",
						"base.enemy.pressure_sentinel",
						"base.enemy.wall_taxer"
					],
					"unused_ids": []
				},
				"act_2": {
					"catalog_id_count": 7,
					"catalog_source": "#87 Act 2 Normal enemy budget: 7 IDs.",
					"evidence_kind": "act_2_encountered",
					"observed_ids": [
						"alpha.enemy.act_two.afterimage",
						"alpha.enemy.act_two.contract_harrier",
						"alpha.enemy.act_two.echo_courier",
						"alpha.enemy.act_two.lien_keeper",
						"alpha.enemy.act_two.pressure_warden",
						"alpha.enemy.act_two.tollkeeper",
						"alpha.enemy.act_two.wall_eater"
					],
					"unused_ids": []
				}
			},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"relics": {
			"catalog_id_count": 50,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"owned_at_summary_ids": [
					"alpha.relic.act_one.ceramic_dial",
					"alpha.relic.act_one.clean_wake",
					"alpha.relic.act_one.harbor_notch",
					"alpha.relic.act_one.settlement_chart",
					"alpha.relic.act_one.steady_keel",
					"alpha.relic.act_one.tide_whistle",
					"alpha.relic.act_one.trade_current",
					"alpha.relic.act_two.cargo_ledger",
					"alpha.relic.act_two.clean_ink",
					"alpha.relic.act_two.crosswind_signal",
					"alpha.relic.act_two.deep_reserve",
					"alpha.relic.act_two.draw_wick",
					"alpha.relic.act_two.echo_index",
					"alpha.relic.act_two.echo_lens",
					"alpha.relic.act_two.final_margin",
					"alpha.relic.act_two.honor_chime",
					"alpha.relic.act_two.ink_filter",
					"alpha.relic.act_two.ledger_shard",
					"alpha.relic.act_two.pairing_knot",
					"alpha.relic.act_two.pressure_bell",
					"alpha.relic.act_two.pressure_rivet",
					"alpha.relic.act_two.pressure_vent",
					"alpha.relic.act_two.quiet_coin",
					"alpha.relic.act_two.reserve_lamp",
					"alpha.relic.act_two.reserve_ribbon",
					"alpha.relic.act_two.sequence_compass",
					"alpha.relic.act_two.settlement_chart",
					"alpha.relic.act_two.settlement_seal",
					"alpha.relic.act_two.stability_cord",
					"alpha.relic.act_two.triplet_compass",
					"alpha.relic.act_two.twin_current",
					"alpha.relic.act_two.wall_surveyor",
					"base.relic.calm_pressure",
					"base.relic.clean_table",
					"base.relic.complete_hand_insurance",
					"base.relic.contamination_filter",
					"base.relic.elite_bounty",
					"base.relic.fatigue_buffer",
					"base.relic.integrity_seal",
					"base.relic.open_hand",
					"base.relic.reserve_sleeve",
					"base.relic.reward_pivot",
					"base.relic.rule_memory",
					"base.relic.sequence_lens",
					"base.relic.shop_ledger",
					"base.relic.skip_stipend",
					"base.relic.triplet_lens",
					"base.relic.wall_survey",
					"base.relic.workshop_kit",
					"base.relic.yaku_notebook"
				],
				"selected_ids": [
					"alpha.relic.act_one.ceramic_dial",
					"alpha.relic.act_one.clean_wake",
					"alpha.relic.act_one.harbor_notch",
					"alpha.relic.act_one.settlement_chart",
					"alpha.relic.act_one.steady_keel",
					"alpha.relic.act_one.tide_whistle",
					"alpha.relic.act_one.trade_current",
					"alpha.relic.act_two.cargo_ledger",
					"alpha.relic.act_two.clean_ink",
					"alpha.relic.act_two.crosswind_signal",
					"alpha.relic.act_two.deep_reserve",
					"alpha.relic.act_two.draw_wick",
					"alpha.relic.act_two.echo_index",
					"alpha.relic.act_two.echo_lens",
					"alpha.relic.act_two.final_margin",
					"alpha.relic.act_two.honor_chime",
					"alpha.relic.act_two.ink_filter",
					"alpha.relic.act_two.ledger_shard",
					"alpha.relic.act_two.pairing_knot",
					"alpha.relic.act_two.pressure_bell",
					"alpha.relic.act_two.pressure_rivet",
					"alpha.relic.act_two.pressure_vent",
					"alpha.relic.act_two.quiet_coin",
					"alpha.relic.act_two.reserve_lamp",
					"alpha.relic.act_two.reserve_ribbon",
					"alpha.relic.act_two.sequence_compass",
					"alpha.relic.act_two.settlement_chart",
					"alpha.relic.act_two.settlement_seal",
					"alpha.relic.act_two.stability_cord",
					"alpha.relic.act_two.triplet_compass",
					"alpha.relic.act_two.twin_current",
					"alpha.relic.act_two.wall_surveyor",
					"base.relic.calm_pressure",
					"base.relic.clean_table",
					"base.relic.complete_hand_insurance",
					"base.relic.contamination_filter",
					"base.relic.elite_bounty",
					"base.relic.fatigue_buffer",
					"base.relic.integrity_seal",
					"base.relic.open_hand",
					"base.relic.reserve_sleeve",
					"base.relic.reward_pivot",
					"base.relic.rule_memory",
					"base.relic.sequence_lens",
					"base.relic.shop_ledger",
					"base.relic.skip_stipend",
					"base.relic.triplet_lens",
					"base.relic.wall_survey",
					"base.relic.workshop_kit",
					"base.relic.yaku_notebook"
				]
			},
			"observed_id_count": 50,
			"observed_ids": [
				"alpha.relic.act_one.ceramic_dial",
				"alpha.relic.act_one.clean_wake",
				"alpha.relic.act_one.harbor_notch",
				"alpha.relic.act_one.settlement_chart",
				"alpha.relic.act_one.steady_keel",
				"alpha.relic.act_one.tide_whistle",
				"alpha.relic.act_one.trade_current",
				"alpha.relic.act_two.cargo_ledger",
				"alpha.relic.act_two.clean_ink",
				"alpha.relic.act_two.crosswind_signal",
				"alpha.relic.act_two.deep_reserve",
				"alpha.relic.act_two.draw_wick",
				"alpha.relic.act_two.echo_index",
				"alpha.relic.act_two.echo_lens",
				"alpha.relic.act_two.final_margin",
				"alpha.relic.act_two.honor_chime",
				"alpha.relic.act_two.ink_filter",
				"alpha.relic.act_two.ledger_shard",
				"alpha.relic.act_two.pairing_knot",
				"alpha.relic.act_two.pressure_bell",
				"alpha.relic.act_two.pressure_rivet",
				"alpha.relic.act_two.pressure_vent",
				"alpha.relic.act_two.quiet_coin",
				"alpha.relic.act_two.reserve_lamp",
				"alpha.relic.act_two.reserve_ribbon",
				"alpha.relic.act_two.sequence_compass",
				"alpha.relic.act_two.settlement_chart",
				"alpha.relic.act_two.settlement_seal",
				"alpha.relic.act_two.stability_cord",
				"alpha.relic.act_two.triplet_compass",
				"alpha.relic.act_two.twin_current",
				"alpha.relic.act_two.wall_surveyor",
				"base.relic.calm_pressure",
				"base.relic.clean_table",
				"base.relic.complete_hand_insurance",
				"base.relic.contamination_filter",
				"base.relic.elite_bounty",
				"base.relic.fatigue_buffer",
				"base.relic.integrity_seal",
				"base.relic.open_hand",
				"base.relic.reserve_sleeve",
				"base.relic.reward_pivot",
				"base.relic.rule_memory",
				"base.relic.sequence_lens",
				"base.relic.shop_ledger",
				"base.relic.skip_stipend",
				"base.relic.triplet_lens",
				"base.relic.wall_survey",
				"base.relic.workshop_kit",
				"base.relic.yaku_notebook"
			],
			"observed_in_catalog_count": 50,
			"subcategories": {},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"rule_breakers": {
			"catalog_id_count": 10,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {
				"owned_at_summary_ids": [
					"alpha.rule_breaker.act_one.stability_surge",
					"alpha.rule_breaker.act_one.tactical_reserve",
					"alpha.rule_breaker.act_two.draw_actions",
					"alpha.rule_breaker.act_two.early_tile",
					"alpha.rule_breaker.act_two.ledger_dividend",
					"alpha.rule_breaker.act_two.reserve_capacity",
					"alpha.rule_breaker.act_two.settlement_capacity",
					"base.rule_breaker.draw_twice",
					"base.rule_breaker.open_table",
					"base.rule_breaker.reserve_witness"
				],
				"selected_ids": [
					"alpha.rule_breaker.act_one.stability_surge",
					"alpha.rule_breaker.act_one.tactical_reserve",
					"alpha.rule_breaker.act_two.draw_actions",
					"alpha.rule_breaker.act_two.early_tile",
					"alpha.rule_breaker.act_two.ledger_dividend",
					"alpha.rule_breaker.act_two.reserve_capacity",
					"alpha.rule_breaker.act_two.settlement_capacity",
					"base.rule_breaker.draw_twice",
					"base.rule_breaker.open_table",
					"base.rule_breaker.reserve_witness"
				]
			},
			"observed_id_count": 10,
			"observed_ids": [
				"alpha.rule_breaker.act_one.stability_surge",
				"alpha.rule_breaker.act_one.tactical_reserve",
				"alpha.rule_breaker.act_two.draw_actions",
				"alpha.rule_breaker.act_two.early_tile",
				"alpha.rule_breaker.act_two.ledger_dividend",
				"alpha.rule_breaker.act_two.reserve_capacity",
				"alpha.rule_breaker.act_two.settlement_capacity",
				"base.rule_breaker.draw_twice",
				"base.rule_breaker.open_table",
				"base.rule_breaker.reserve_witness"
			],
			"observed_in_catalog_count": 10,
			"subcategories": {},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"techniques": {
			"catalog_id_count": 24,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog. 21 Run Techniques plus 3 Character Core Techniques.",
			"catalog_status": "DECLARED",
			"evidence": {
				"owned_at_summary_ids": [
					"alpha.technique.core.harbor_read",
					"base.technique.core.reserve_ledger",
					"base.technique.core.sequence_line"
				]
			},
			"observed_id_count": 3,
			"observed_ids": [
				"alpha.technique.core.harbor_read",
				"base.technique.core.reserve_ledger",
				"base.technique.core.sequence_line"
			],
			"observed_in_catalog_count": 3,
			"subcategories": {
				"core_techniques": {
					"catalog_id_count": 3,
					"catalog_source": "#87 Character Core Technique budget: 3 IDs.",
					"evidence_kind": "",
					"observed_ids": [
						"alpha.technique.core.harbor_read",
						"base.technique.core.reserve_ledger",
						"base.technique.core.sequence_line"
					],
					"unused_ids": []
				},
				"run_techniques": {
					"catalog_id_count": 21,
					"catalog_source": "#87 Run Technique budget: 21 IDs.",
					"evidence_kind": "",
					"observed_ids": [],
					"unused_ids": [
						"alpha.technique.cleansing_call",
						"alpha.technique.draw_capacity",
						"alpha.technique.first_measure",
						"alpha.technique.harbor_strike",
						"alpha.technique.last_measure",
						"alpha.technique.ledger_wind",
						"alpha.technique.pressure_dividend",
						"alpha.technique.pressure_turn",
						"alpha.technique.refinement_practice",
						"alpha.technique.reserve_survey",
						"alpha.technique.river_step",
						"alpha.technique.settlement_mirror",
						"alpha.technique.tide_draw",
						"base.technique.clean_table",
						"base.technique.draw_surge",
						"base.technique.pressure_break",
						"base.technique.reaction_guard",
						"base.technique.reserve_exchange",
						"base.technique.settlement_focus",
						"base.technique.stability_breath",
						"base.technique.yaku_insight"
					]
				}
			},
			"unexpected_observed_ids": [],
			"unused_ids": [
				"alpha.technique.cleansing_call",
				"alpha.technique.draw_capacity",
				"alpha.technique.first_measure",
				"alpha.technique.harbor_strike",
				"alpha.technique.last_measure",
				"alpha.technique.ledger_wind",
				"alpha.technique.pressure_dividend",
				"alpha.technique.pressure_turn",
				"alpha.technique.refinement_practice",
				"alpha.technique.reserve_survey",
				"alpha.technique.river_step",
				"alpha.technique.settlement_mirror",
				"alpha.technique.tide_draw",
				"base.technique.clean_table",
				"base.technique.draw_surge",
				"base.technique.pressure_break",
				"base.technique.reaction_guard",
				"base.technique.reserve_exchange",
				"base.technique.settlement_focus",
				"base.technique.stability_breath",
				"base.technique.yaku_insight"
			]
		},
		"tiles": {
			"catalog_id_count": null,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "NO_ACCEPTED_DENOMINATOR",
			"evidence": {
				"owned_at_summary_ids": [
					"base.tile.bamboo.1",
					"base.tile.bamboo.2",
					"base.tile.bamboo.3",
					"base.tile.bamboo.4",
					"base.tile.bamboo.5",
					"base.tile.bamboo.6",
					"base.tile.bamboo.7",
					"base.tile.bamboo.8",
					"base.tile.bamboo.9",
					"base.tile.characters.1",
					"base.tile.characters.2",
					"base.tile.characters.3",
					"base.tile.characters.4",
					"base.tile.characters.5",
					"base.tile.characters.6",
					"base.tile.characters.7",
					"base.tile.characters.8",
					"base.tile.characters.9",
					"base.tile.dots.1",
					"base.tile.dots.2",
					"base.tile.dots.4",
					"base.tile.dots.5",
					"base.tile.dots.6",
					"base.tile.dots.7",
					"base.tile.dots.8",
					"base.tile.dots.9",
					"base.tile.honors.east",
					"base.tile.honors.green",
					"base.tile.honors.north",
					"base.tile.honors.red",
					"base.tile.honors.south",
					"base.tile.honors.west",
					"base.tile.honors.white"
				],
				"selected_ids": [
					"base.tile.bamboo.1",
					"base.tile.bamboo.2",
					"base.tile.bamboo.3",
					"base.tile.bamboo.4",
					"base.tile.bamboo.5",
					"base.tile.bamboo.6",
					"base.tile.bamboo.7",
					"base.tile.bamboo.8",
					"base.tile.bamboo.9",
					"base.tile.characters.1",
					"base.tile.characters.2",
					"base.tile.characters.3",
					"base.tile.characters.4",
					"base.tile.characters.5",
					"base.tile.characters.6",
					"base.tile.characters.7",
					"base.tile.characters.8",
					"base.tile.characters.9",
					"base.tile.dots.1",
					"base.tile.dots.2",
					"base.tile.dots.4",
					"base.tile.dots.5",
					"base.tile.dots.6",
					"base.tile.dots.7",
					"base.tile.dots.8",
					"base.tile.honors.east",
					"base.tile.honors.green",
					"base.tile.honors.north",
					"base.tile.honors.red",
					"base.tile.honors.south",
					"base.tile.honors.west",
					"base.tile.honors.white"
				]
			},
			"observed_id_count": 33,
			"observed_ids": [
				"base.tile.bamboo.1",
				"base.tile.bamboo.2",
				"base.tile.bamboo.3",
				"base.tile.bamboo.4",
				"base.tile.bamboo.5",
				"base.tile.bamboo.6",
				"base.tile.bamboo.7",
				"base.tile.bamboo.8",
				"base.tile.bamboo.9",
				"base.tile.characters.1",
				"base.tile.characters.2",
				"base.tile.characters.3",
				"base.tile.characters.4",
				"base.tile.characters.5",
				"base.tile.characters.6",
				"base.tile.characters.7",
				"base.tile.characters.8",
				"base.tile.characters.9",
				"base.tile.dots.1",
				"base.tile.dots.2",
				"base.tile.dots.4",
				"base.tile.dots.5",
				"base.tile.dots.6",
				"base.tile.dots.7",
				"base.tile.dots.8",
				"base.tile.dots.9",
				"base.tile.honors.east",
				"base.tile.honors.green",
				"base.tile.honors.north",
				"base.tile.honors.red",
				"base.tile.honors.south",
				"base.tile.honors.west",
				"base.tile.honors.white"
			],
			"observed_in_catalog_count": 0,
			"subcategories": {},
			"unexpected_observed_ids": [],
			"unused_ids": []
		},
		"yaku": {
			"catalog_id_count": 24,
			"catalog_source": "GitHub issue #87 accepted production content budget; IDs from Phase2Catalog, AlphaScaleCatalog, and AlphaActTwoCatalog.",
			"catalog_status": "DECLARED",
			"evidence": {},
			"observed_id_count": 0,
			"observed_ids": [],
			"observed_in_catalog_count": 0,
			"subcategories": {},
			"unexpected_observed_ids": [],
			"unused_ids": [
				"alpha.yaku.character_flow",
				"alpha.yaku.character_majority",
				"alpha.yaku.dot_majority",
				"alpha.yaku.dotted_river",
				"alpha.yaku.double_sequence",
				"alpha.yaku.honor_beacon",
				"alpha.yaku.honor_chorus",
				"alpha.yaku.honor_gathering",
				"alpha.yaku.mixed_quartet",
				"alpha.yaku.pair_archive",
				"alpha.yaku.pair_triad",
				"alpha.yaku.quad_duet",
				"alpha.yaku.quad_pair",
				"alpha.yaku.sequence_cascade",
				"alpha.yaku.sequence_pair",
				"alpha.yaku.sequence_quad",
				"alpha.yaku.sequence_triplet",
				"alpha.yaku.sequence_triplet_pair",
				"alpha.yaku.triplet_duet",
				"alpha.yaku.triplet_pair",
				"alpha.yaku.triplet_quad",
				"alpha.yaku.triplet_row",
				"base.yaku.bamboo_concentration",
				"base.yaku.pair_foundation"
			]
		}
	},
	"scope": "OBSERVED_SELECTION_OWNERSHIP_ACTIVATION_SCORING_AND_ENCOUNTER_EVIDENCE",
	"unobservable_categories": [
		"Per-item effect invocation counts and value-level effect outcomes are not represented by the collected factual evidence.",
		"Tile IDs are reported when observed, but issue #87 defines no accepted Tile denominator."
	]
}
```

## Failures, divergences, and visible outliers

Visible outliers need one recorded content-owner decision each. The subgate cannot pass while a decision is pending or requests remediation/retest. Defeat is a valid terminal outcome; no win-rate target is applied.

```json
{
	"content_owner_review": {
		"disposition_file_path": "",
		"disposition_file_sha256": "",
		"dispositions": [],
		"gate_clear": true,
		"schema": "alpha.gate-corpus-outlier-dispositions.v1",
		"status": "NO_VISIBLE_OUTLIERS",
		"visible_outlier_count": 0
	},
	"invalid_attempts": [],
	"profile_errors": [],
	"repeat_divergences": [],
	"visible_outliers": []
}
```

## Evidence limits

No player-duration or device-performance evidence is claimed; elapsed_msec is only an attempt-watchdog diagnostic.
